console.log('\'Allo \'Allo!');
